package com.example.networkmonitoring.model;

public class Device {
    private String name;
    private String cpuUsage;
    private String status;

    public Device(String name, String cpuUsage, String status) {
        this.name = name;
        this.cpuUsage = cpuUsage;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCpuUsage() {
        return cpuUsage;
    }

    public void setCpuUsage(String cpuUsage) {
        this.cpuUsage = cpuUsage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

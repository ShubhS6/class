package com.example.networkmonitoring.controller;

import com.example.networkmonitoring.model.Device;
import com.example.networkmonitoring.service.SnmpService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
class NetworkControllerTest {

    private NetworkController networkController;
    private SnmpService snmpService;
    private Model model;

    @BeforeEach
    void setUp() {
    	snmpService = Mockito.mock(SnmpService.class);
        networkController = new NetworkController();
        networkController.snmpService = snmpService;
        model = Mockito.mock(Model.class);
    }
    @Test
    void testHome() {
        String viewName = networkController.home(model);

        assertEquals("index", viewName);
        verify(model, times(1)).addAttribute(eq("devices"), any(List.class));
    }

    @Test
    void testFetchMetrics() throws Exception {
        when(snmpService.getAsString(anyString(), anyString(), anyString())).thenReturn("50%");

        String viewName = networkController.fetchMetrics("127.0.0.1", "public", "1.3.6.1.2.1.25.3.3.1.2.196608", model);

        assertEquals("index", viewName);
        verify(model, times(1)).addAttribute("cpuUsage", "50%");
    }

    @Test
    void testFetchMetricsError() throws Exception {
        when(snmpService.getAsString(anyString(), anyString(), anyString())).thenThrow(new Exception("SNMP Error"));

        String viewName = networkController.fetchMetrics("127.0.0.1", "public", "1.3.6.1.2.1.25.3.3.1.2.196608", model);
        assertEquals("index", viewName);
        verify(model, times(1)).addAttribute("cpuUsage", "Error: SNMP Error");
    }
}

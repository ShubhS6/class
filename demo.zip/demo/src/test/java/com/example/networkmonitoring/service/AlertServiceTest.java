package com.example.networkmonitoring.service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AlertServiceTest {
 

private AlertService alertService;
    private JavaMailSender mailSender;

    @BeforeEach
    void setUp() {
        mailSender = Mockito.mock(JavaMailSender.class);
        alertService = new AlertService();
        alertService.mailSender = mailSender;
        alertService.recipientEmail = "test@example.com";
        alertService.cpuThreshold = 80.0;
    }

    @Test
    void testCheckThreshold() {
        alertService.checkThreshold("CPU Usage", 85.0);
        ArgumentCaptor<SimpleMailMessage> messageCaptor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(messageCaptor.capture());

        SimpleMailMessage message = messageCaptor.getValue();
        assertEquals("test@example.com", message.getTo()[0]);
        assertEquals("Alert: CPU Usage Threshold Exceeded", message.getSubject());
        assertEquals("The CPU Usage has exceeded the threshold. Current value: 85.0", message.getText());
    }

    @Test
    void testCheckThresholdNoAlert() {
        alertService.checkThreshold("CPU Usage", 75.0);
        Mockito.verifyNoInteractions(mailSender);
    }
}

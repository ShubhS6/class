package com.cts.jpa.pagesort;

public class PaginationSortingExampleApplicationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

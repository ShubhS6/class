package com.spring.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

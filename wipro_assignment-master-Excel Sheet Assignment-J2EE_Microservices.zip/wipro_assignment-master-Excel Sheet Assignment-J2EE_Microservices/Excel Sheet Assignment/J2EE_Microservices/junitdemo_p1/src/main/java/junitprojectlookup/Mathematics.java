package junitprojectlookup;

public class Mathematics {

		
		public int add(int a, int b) {
			return a + b;
		}
	 
	}



package com.restdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

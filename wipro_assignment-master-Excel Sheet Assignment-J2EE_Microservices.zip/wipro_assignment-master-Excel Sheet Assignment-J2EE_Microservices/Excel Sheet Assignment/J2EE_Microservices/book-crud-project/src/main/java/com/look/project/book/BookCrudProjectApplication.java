package com.look.project.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookCrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookCrudProjectApplication.class, args);
	}

}

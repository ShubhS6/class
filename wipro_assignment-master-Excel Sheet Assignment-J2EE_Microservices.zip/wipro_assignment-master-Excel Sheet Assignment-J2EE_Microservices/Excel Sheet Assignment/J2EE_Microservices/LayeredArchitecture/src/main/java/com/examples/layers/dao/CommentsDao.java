package com.examples.layers.dao;

import java.util.List;

import com.examples.layers.model.Student;

public interface CommentsDao {
	
	public List<Student> getAllStudent();
	public int addName(Student name);
	public Student searchName(int studentId);
	public void deleteName(int studentId);

}

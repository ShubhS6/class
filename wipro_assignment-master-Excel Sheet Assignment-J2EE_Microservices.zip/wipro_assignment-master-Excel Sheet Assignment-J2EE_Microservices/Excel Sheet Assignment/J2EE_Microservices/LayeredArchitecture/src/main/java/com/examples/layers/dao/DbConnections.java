package com.examples.layers.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnections {
	
	public static Connection con = null;
	public static Connection getDatabaseConnection() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/trainerdb", "root", "Welcome@12345");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}

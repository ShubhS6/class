package com.examples.layers.service;
import java.util.List;
import com.examples.layers.dao.CommentsDao;
import com.examples.layers.dao.CommentsDaoImpl;
import com.examples.layers.model.Student;
public class CommentServiceImpl implements CommentsService {
	
	CommentsDao dao;
	
	public CommentServiceImpl() {
		super();
		this.dao = new CommentsDaoImpl();
	}
	@Override
	public List<Student> getAllStudent() {
		return dao.getAllStudent();
	}
	@Override
	public int addName(Student name) {
		return dao.addName(name);
	}
	@Override
	public Student searchName(int studentId) {
		return dao.searchName(studentId);
	}
	@Override
	public void deleteName(int studentId) {
		dao.deleteName(studentId);
  }
}

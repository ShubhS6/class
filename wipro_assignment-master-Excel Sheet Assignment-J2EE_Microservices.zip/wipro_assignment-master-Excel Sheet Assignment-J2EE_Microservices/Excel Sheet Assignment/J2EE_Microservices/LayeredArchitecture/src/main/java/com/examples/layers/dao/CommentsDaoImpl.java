package com.examples.layers.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.examples.layers.model.Student;

public class CommentsDaoImpl implements CommentsDao {
	
	Statement st =null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	Connection con = null;
	List<Student> student = null;
	int k=0;
	
	@Override
	public List<Student> getAllStudent() {
		student = new ArrayList<>();
		con = DbConnections.getDatabaseConnection();
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query = "select * from Student";
		try {
			rs = st.executeQuery(query);
			while(rs.next()) {
				student.add(new Student(rs.getInt(1),rs.getString(2),rs.getInt(3)));	
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return student;
	}
	@Override 
	public int addName(Student name) {
		String sql = "insert into student values(?,?,?,?)";
		
		con = DbConnections.getDatabaseConnection();
		
		try {
			pst = con.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pst.setInt(1, name.getStudentId());
			pst.setString(2, name.getName());
			pst.setInt(3, name.getAge());
			
			k = pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return k;
	}
	
	@Override
	public Student searchName(int studentId) {
		return null;
	}
	@Override
	public void deleteName(int studentId) {
		
	}


}

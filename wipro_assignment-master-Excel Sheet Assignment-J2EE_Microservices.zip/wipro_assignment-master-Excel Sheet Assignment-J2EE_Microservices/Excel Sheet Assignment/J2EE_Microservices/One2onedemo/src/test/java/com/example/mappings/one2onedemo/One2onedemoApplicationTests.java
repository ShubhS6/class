package com.example.mappings.one2onedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class One2onedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

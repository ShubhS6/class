/**
 * 
 */
/**
 * 
 */
module practicetask {
}
package project;


	import java.time.LocalDate;
	import java.time.format.DateTimeFormatter;
	 
	public class LocalDateExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			LocalDate today = LocalDate.now();
			System.out.println("Today: "+today);
			
			LocalDate dateOfBirth = LocalDate.of(1990, 12, 15);
			System.out.println("Date of Birth: "+dateOfBirth);
			
			LocalDate dateOfJoining = LocalDate.parse("2015-12-15");
			System.out.println("Date of Joining: "+dateOfJoining);
			
			System.out.println("Year: "+today.getYear());
			System.out.println("Month: "+today.getMonth());
			System.out.println("Day of Month: "+today.getDayOfMonth());
			System.out.println("Day of Week: "+today.getDayOfWeek());
			System.out.println("Day of Year: "+today.getDayOfYear());
			
			System.out.println("Is Leap Year: "+today.isLeapYear());
			
			LocalDate tomorrow = today.plusDays(1);
			System.out.println("Tomorrow: "+tomorrow);
			System.out.println(today.plusWeeks(1));
			System.out.println(today.plusMonths(1));
			System.out.println(today.plusYears(1));
			
			LocalDate previousMonth = today.minusMonths(1);
			System.out.println("Previous Month: "+previousMonth);
			System.out.println(today.minusWeeks(1));
			System.out.println(today.minusDays(1));
			System.out.println(today.minusYears(1));
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			String formattedDate = today.format(formatter);
			System.out.println("Formatted Date: "+formattedDate);
			
		}
	 
	}



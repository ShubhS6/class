package project;


	import java.time.ZoneId;
	import java.time.ZonedDateTime;
	 
	public class ZoneDateTimeExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			//ZoneDateTime Example
			//ZoneDateTime is an immutable representation of a date-time with a time-zone.
			
			ZonedDateTime zdt = ZonedDateTime.now();
			System.out.println(zdt);
			
			// set Los Angeles timezone
			ZonedDateTime lzdt = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
			System.out.println("Current Date and Time in LosAngeles -->"+lzdt);
			
			// set Tokyo timezone
			ZonedDateTime tzdt = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
			System.out.println("Current Date and Time in Tokyo -->"+tzdt);
		}
	 
	}
	 
	



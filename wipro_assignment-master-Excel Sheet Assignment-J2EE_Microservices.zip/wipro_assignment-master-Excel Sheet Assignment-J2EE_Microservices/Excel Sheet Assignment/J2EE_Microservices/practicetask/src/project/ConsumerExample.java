package project;


	import java.util.function.Consumer;
	import java.util.function.Function;
	 
	public class ConsumerExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Consumer<Integer> c =  x -> {
				int f=1;
				for(int i=2;i<=x;i++)
					f=f*i;
				System.out.println("The factorial is "+f);
			};
			
			Consumer<Student> c1 = s -> {
				System.out.println("Name: " + s.name);
				System.out.println("Marks: " + s.marks);
				System.out.println("Result: " + s.result);
			};
			
			Function<Student, Student> f = s -> {
				if (s.marks >= 60)
					s.result = "First class";
				else if (s.marks >= 50 && s.marks < 60)
					s.result = "Second class";
				else if (s.marks >= 40 && s.marks < 50)
					s.result = "Third class";
				else
					s.result = "Fail";
				return s;
			};
			
			
			c.accept(5); // 120
			c.accept(6); // 720
			
			c1.accept(f.apply(new Student("John", 90)));
			c1.accept(f.apply(new Student("Mike", 55)));
			c1.accept(f.apply(new Student("Daisy", 45)));
			c1.accept(f.apply(new Student("Tom", 35)));
	 
		}
	 
	}


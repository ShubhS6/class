package project;


	import java.time.LocalDateTime;
	 
	public class LocalDateTimeExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			//LocalDateTime
			LocalDateTime ldt = LocalDateTime.now();
			System.out.println(ldt);
		
			//LocalDateTime.of()
			LocalDateTime ldt1 = LocalDateTime.of(2020, 12, 25, 10, 30);
			System.out.println(ldt1);
			
			//LocalDateTime.parse()
			LocalDateTime ldt2 = LocalDateTime.parse("2020-12-25T10:30:00");
			System.out.println(ldt2);
			
			//Extract the date and time details individually
			System.out.println("Year: "+ldt.getYear());
			System.out.println("Month: "+ldt.getMonth());
			System.out.println("Day of Month: "+ldt.getDayOfMonth());
			System.out.println("Day of Week: "+ldt.getDayOfWeek());
			System.out.println("Day of Year: "+ldt.getDayOfYear());
			System.out.println("Hour: "+ldt.getHour());
			System.out.println("Minute: "+ldt.getMinute());
			System.out.println("Second: "+ldt.getSecond());
			System.out.println("Nano: "+ldt.getNano());
			
			// Arithmetic operations on LocalDateTime
			LocalDateTime ldt3 = ldt.plusDays(5);
			System.out.println(ldt3);
			
			//Add and substract hours, minutes, seconds and nanoseconds, days, months and years
			LocalDateTime ldt4 = ldt.minusHours(5);
			System.out.println(ldt4);
			
			LocalDateTime ldt5 = ldt.plusHours(5);
			System.out.println(ldt5);
			
			LocalDateTime ldt6 = ldt.minusMinutes(10);
			System.out.println(ldt6);
			
			LocalDateTime ldt7 = ldt.plusMinutes(10);
			System.out.println(ldt7);
			
			LocalDateTime ldt8 = ldt.minusSeconds(20);
			System.out.println(ldt8);
			
			LocalDateTime ldt9 = ldt.plusSeconds(20);
			System.out.println(ldt9);
			
			LocalDateTime ldt10 = ldt.minusNanos(1000000000);
			System.out.println(ldt10);
			
			LocalDateTime ldt11 = ldt.plusNanos(1000000000);
			System.out.println(ldt11);
			
			LocalDateTime ldt12 = ldt.minusMonths(2);
			System.out.println(ldt12);
			
			LocalDateTime ldt13 = ldt.plusMonths(2);
			System.out.println(ldt13);
			
			LocalDateTime ldt14 = ldt.minusYears(2);
			System.out.println(ldt14);
			
			LocalDateTime ldt15 = ldt.plusYears(2);
			System.out.println(ldt15);
			
			//Comparison of LocalDateTime
			System.out.println(ldt.isAfter(ldt1));
			System.out.println(ldt.isBefore(ldt1));
			System.out.println(ldt.isEqual(ldt1));
		}
	 
	}



package project;


	import java.util.function.Function;
	 
	public class FunctionExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Function<Integer,Integer> f = x -> {
				int f1=1;
				for(int i=2;i<=x;i++)
					f1=f1*i;
				return f1;
			};
			System.out.println(f.apply(5)); // 120
			System.out.println(f.apply(6)); // 720
			
			Function<Integer,Double> f2 = radius -> 3.14*radius*radius;
			System.out.println("The area of circle with radius 5 is  "+f2.apply(5)); // 78.5
			System.out.println("The area of circle with radius 6 is  "+f2.apply(6)); // 113.04
			
			Function<Integer,Integer> f3 = x -> x*x;
			Function<Integer,Integer> f4 = x -> x/2;
			
			System.out.println(f3.apply(4)); // 16
			System.out.println(f4.apply(4)); // 2
			
			System.out.println(f3.andThen(f4).apply(5)); // 12
			System.out.println(f3.compose(f4).apply(5)); // 4
		}
	 
	}



package project;


	import java.util.function.Function;
	 
	public class TestStudent {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Function<Student, Student> f = s -> {
				if (s.marks >= 60)
					s.result = "First class";
				else if (s.marks >= 50 && s.marks < 60)
					s.result = "Second class";
				else if (s.marks >= 40 && s.marks < 50)
					s.result = "Third class";
				else
					s.result = "Fail";
				return s;
			};
			
			Student s1 = new Student("John", 90);
			Student s2 = new Student("Mike", 55);
			Student s3 = new Student("Daisy", 45);
			Student s4 = new Student("Tom", 35);
			
			//Student s = f.apply(s1);
			//s.showDetails();
			
			f.apply(s1).showDetails();
			f.apply(s2).showDetails();
			f.apply(s3).showDetails();
			f.apply(s4).showDetails();
			
	 
		}
	 
	}



package project;


	import java.time.Duration;
	import java.time.LocalDate;
	import java.time.LocalTime;
	import java.time.Period;
	 
	public class PeriodDurationExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			//Period
			LocalDate date1 = LocalDate.now();
			LocalDate date2 = LocalDate.of(1979, 01, 19);
			
			Period period = Period.between(date2, date1);
			
			// Get the details of period
			System.out.println("Years: "+period.getYears());
			System.out.println("Months: "+period.getMonths());
			System.out.println("Days: "+period.getDays());
			
			// Arthimetic Operations on Period
			
			// Duration
		    LocalTime time1 = LocalTime.now();
		    LocalTime time2 = LocalTime.of(1, 30, 10);
		    Duration duration = Duration.between(time2, time1);
		    // get the deatils of duration
		    System.out.println("Hours: "+duration.toHours());
		    System.out.println("Minutes: "+duration.toMinutes());
		    System.out.println("Seconds: "+duration.getSeconds());
		    System.out.println("Nano Seconds: "+duration.getNano());
			
	 
		}
	 
	}



package project;


	public class Square implements Shape {
		 
		@Override
		public int area(int side) {
			// TODO Auto-generated method stub
			return side*side;
		}
	 
	}



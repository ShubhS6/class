package project;
import java.util.function.Predicate;

	
	 
	public class TestUser {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Predicate<User> p = user -> user.username.equals("admin") &&
										user.password.equals("admin");
			
			User user1 = new User("admin", "admin");
			User user2 = new User("admin", "admin1");
			
			if(p.test(user2))
	            System.out.println("Valid user");
	            else
	            	System.out.println("Invalid user");
	    }
	 
	}



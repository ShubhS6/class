package project;

public interface Shape {


		
		public int area(int side);
	 
	}
	 

	

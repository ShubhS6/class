package project;


	import java.util.function.BiConsumer;
	import java.util.function.BiFunction;
	import java.util.function.BiPredicate;
	 
	public class BiParameterExamples {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			BiPredicate<Integer,Integer> p = (a,b) -> a>b;
			System.out.println(p.test(10, 20));
			
			BiPredicate<String,String> p1 = (s1,s2) -> s1.length()>s2.length();
			System.out.println(p1.test("Hello", "World"));
			
			BiConsumer<Integer,Integer> c = (a,b) -> System.out.println("Addition: "+(a+b));
			c.accept(10, 20);
			
			BiConsumer<String,String> c1 = (s1,s2) -> System.out.println(s1+s2);
			c1.accept("Hello", "World");
			
			BiFunction<Integer,Integer,Integer> f = (a,b) -> a+b;
			System.out.println(f.apply(10, 20));
			
			BiFunction<Integer,Integer,Double> f1 = (a,b) -> Math.pow(a, b);
			System.out.println(f1.apply(2, 3));
			
			
	 
		}
	 
	}
	 



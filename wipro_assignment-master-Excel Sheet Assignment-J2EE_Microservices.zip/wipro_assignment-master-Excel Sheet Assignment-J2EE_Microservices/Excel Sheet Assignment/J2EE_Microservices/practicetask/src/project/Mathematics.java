package project;


	@FunctionalInterface
	public interface Mathematics {
		
		public int add(int a, int b);
	 
		public default int subtract(int a, int b) {
			return a - b;
		}
	 
		public static int multiply(int a, int b) {
			return a * b;
		}
	}
	 



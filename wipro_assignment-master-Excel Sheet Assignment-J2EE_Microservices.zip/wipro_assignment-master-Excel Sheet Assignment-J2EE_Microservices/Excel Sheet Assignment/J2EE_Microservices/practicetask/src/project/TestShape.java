package project;


	public class TestShape {
		 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			//Shape shape = new Square();
			Shape shape = side -> side*side;
			System.out.println("Area of Square: "+shape.area(10));
			
			Mathematics m = (a,b) -> a+b;
			System.out.println("Addition: "+m.add(10, 20));
			System.out.println("Subtraction: "+m.subtract(10, 20));
			System.out.println("Multiplication: "+Mathematics.multiply(10, 20));
	 
			Runnable r = () -> {
					for(int i=0; i<10; i++)
						System.out.println(i);
			};
			
			Thread t = new Thread(r);
			t.start();
			
		
		}
	 
	}



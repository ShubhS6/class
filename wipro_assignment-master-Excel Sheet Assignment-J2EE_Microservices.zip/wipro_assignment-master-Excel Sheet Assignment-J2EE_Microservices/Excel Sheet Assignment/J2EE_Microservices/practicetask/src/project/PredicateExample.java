package project;
import java.util.function.Predicate;

	
	 
	public class PredicateExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Predicate<Integer> p = i -> i%2==0;
			System.out.println(p.test(10)); // true
			System.out.println(p.test(15)); // false
			
			Predicate<String> p1 = s -> s.length()>5;
			System.out.println(p1.test("Hello")); // false
			System.out.println(p1.test("Hello World")); // true
			
			Predicate<Integer> p3 = i -> i>20;
			System.out.println(p3.test(10)); // false
			System.out.println(p3.test(25)); // true
			
			Predicate<String> p4 = s -> s.startsWith("A");
			System.out.println(p4.test("Hello")); // false
			System.out.println(p4.test("Apple")); // true
			
			// check if the given number is even and greater than 20
			// Predicate chaining
			
			System.out.println(p.and(p3).test(10)); // false
			System.out.println(p.and(p3).test(24)); // true
			
			System.out.println(p.or(p3).test(10)); //true
			System.out.println(p.or(p3).test(24)); // true
			
			System.out.println(p.negate().test(10)); // false
			System.out.println(p.negate().test(5)); // true
			
		}
	 
	}
	 



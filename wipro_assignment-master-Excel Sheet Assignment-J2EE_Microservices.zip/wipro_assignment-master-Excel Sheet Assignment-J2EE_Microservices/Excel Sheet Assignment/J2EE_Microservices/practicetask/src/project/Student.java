package project;


	public class Student {
		String name;
		int marks;
		String result;
	 
		public Student(String name, int marks) {
			this.name = name;
			this.marks = marks;
		}
		
		public void showDetails() {
			System.out.println("Name: " + name);
			System.out.println("Marks: " + marks);
			System.out.println("Result: " + result);
		}
	}



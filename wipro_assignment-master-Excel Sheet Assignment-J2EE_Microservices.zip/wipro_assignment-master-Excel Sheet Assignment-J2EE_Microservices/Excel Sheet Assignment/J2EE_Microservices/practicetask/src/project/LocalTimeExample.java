package project;


	import java.time.LocalTime;
	 
	public class LocalTimeExample {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			//LocalTime
			//Represents time without time zone
			LocalTime time = LocalTime.now();
			System.out.println(time);
			
			LocalTime time1 = LocalTime.of(23, 20, 55);
			System.out.println(time1);
			
			// Extract hour, minute, second
			System.out.println(time.getHour());
			System.out.println(time.getMinute());
			System.out.println(time.getSecond());
			
			//Adding hours, minutes, seconds
			System.out.println(time.plusHours(2));
			System.out.println(time.plusMinutes(10));
			System.out.println(time.plusSeconds(20));
			
			//Substracting hours, minutes, seconds
			System.out.println(time.minusHours(2));
			System.out.println(time.minusMinutes(10));
			System.out.println(time.minusSeconds(20));
			
			//Comparing times
			System.out.println(time.isBefore(time1));
			System.out.println(time.isAfter(time1));
			System.out.println(time.equals(time1));
			
			//Creating time from string
			String timeStr = "10:15:30";
			LocalTime time2 = LocalTime.parse(timeStr);
			System.out.println(time2);
	 
		}
	 
	}



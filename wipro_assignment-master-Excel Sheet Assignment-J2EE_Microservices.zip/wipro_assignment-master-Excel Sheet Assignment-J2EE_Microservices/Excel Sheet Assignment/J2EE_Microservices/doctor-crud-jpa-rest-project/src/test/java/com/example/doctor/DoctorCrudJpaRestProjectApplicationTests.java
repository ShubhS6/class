package com.example.doctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorCrudJpaRestProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceRestDatajpaCrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceRestDatajpaCrudProjectApplication.class, args);
	}

}

package thread;

public class ThreadDemo extends Thread {
	public void run() {
		System.out.println("ThreadDemo is running");
		for (int i = 0; i < 100; i++) {
			System.out.println("ThreadDemo: " + i);
			try {
				this.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}



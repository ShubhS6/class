package thread;


	import java.util.LinkedList;
	import java.util.Queue;
	import java.util.Random;
	 
	class ProducerConsumerWithSync {
	 
	    // Shared buffer and buffer size
	    private static final int BUFFER_SIZE = 5;
	    private static Queue<Integer> buffer = new LinkedList<>();
	    private static final Object lock = new Object();
	    private static Random random = new Random();
	 
	    public static void main(String[] args) {
	        Thread producerThread = new Thread(new Producer());
	        Thread consumerThread = new Thread(new Consumer());
	 
	        producerThread.start();
	        consumerThread.start();
	    }
	 
	    static class Producer implements Runnable {
	        @Override
	        public void run() {
	            while (true) {
	                synchronized (lock) {
	                    while (buffer.size() >= BUFFER_SIZE) {
	                        try {
	                            System.out.println("Buffer is full! Producer is waiting...");
	                            lock.wait();
	                        } catch (InterruptedException e) {
	                            e.printStackTrace();
	                        }
	                    }
	 
	                    int item = random.nextInt(100);
	                    buffer.add(item);
	                    System.out.println("Producer produced: " + item);
	                    lock.notifyAll();
	                }
	 
	                try {
	                    Thread.sleep(random.nextInt(1000));
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	 
	    static class Consumer implements Runnable {
	        @Override
	        public void run() {
	            while (true) {
	                synchronized (lock) {
	                    while (buffer.isEmpty()) {
	                        try {
	                            System.out.println("Buffer is empty! Consumer is waiting...");
	                            lock.wait();
	                        } catch (InterruptedException e) {
	                            e.printStackTrace();
	                        }
	                    }
	 
	                    int item = buffer.poll();
	                    System.out.println("Consumer consumed: " + item);
	                    lock.notifyAll();
	                }
	 
	                try {
	                    Thread.sleep(random.nextInt(1000));
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	}
	 



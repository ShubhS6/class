package thread;

public class ThreadsMethodsDemo {

		 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			ThreadDemo threadDemo = new ThreadDemo();
			// methods of Thread class
			System.out.println("Name of thread: " + threadDemo.getName());
			System.out.println("Id of thread: " + threadDemo.getId());
			System.out.println("Priority of thread: " + threadDemo.getPriority());
			System.out.println("State of thread: " + threadDemo.getState());
			System.out.println("Thread is alive: " + threadDemo.isAlive());
			System.out.println("Thread is daemon: " + threadDemo.isDaemon());
			System.out.println("Thread is interrupted: " + threadDemo.isInterrupted());
			System.out.println("Thread group of thread: " + threadDemo.getThreadGroup());
			threadDemo.setName("My Wipro Thread");
			System.out.println("Name of thread: " + threadDemo.getName());
			threadDemo.setPriority(10);
			System.out.println("Priority of thread: " + threadDemo.getPriority());
			threadDemo.setDaemon(true);
			System.out.println("Thread is daemon: " + threadDemo.isDaemon());
			
		}
	 
	}



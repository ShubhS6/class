package thread;


	import java.util.LinkedList;
	import java.util.Queue;
	import java.util.Random;
	 
	class ProducerConsumerWithoutSync {
	 
	    // Shared buffer and buffer size
	    private static final int BUFFER_SIZE = 5;
	    private static Queue<Integer> buffer = new LinkedList<>();
	    private static Random random = new Random();
	 
	    public static void main(String[] args) {
	        Thread producerThread = new Thread(new Producer());
	        Thread consumerThread = new Thread(new Consumer());
	 
	        producerThread.start();
	        consumerThread.start();
	    }
	 
	    static class Producer implements Runnable {
	        @Override
	        public void run() {
	            while (true) {
	                if (buffer.size() < BUFFER_SIZE) {
	                    int item = random.nextInt(100);
	                    buffer.add(item);
	                    System.out.println("Producer produced: " + item);
	                } else {
	                    System.out.println("Buffer is full! Producer is waiting...");
	                }
	                try {
	                    Thread.sleep(random.nextInt(1000));
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	 
	    static class Consumer implements Runnable {
	        @Override
	        public void run() {
	            while (true) {
	                if (!buffer.isEmpty()) {
	                    int item = buffer.poll();
	                    System.out.println("Consumer consumed: " + item);
	                } else {
	                    System.out.println("Buffer is empty! Consumer is waiting...");
	                }
	                try {
	                    Thread.sleep(random.nextInt(1000));
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	}
	 
	 



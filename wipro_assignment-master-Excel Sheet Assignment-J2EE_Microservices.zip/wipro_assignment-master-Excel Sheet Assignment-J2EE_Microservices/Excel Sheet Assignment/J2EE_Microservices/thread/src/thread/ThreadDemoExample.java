package thread;


	public class ThreadDemoExample {
		 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			ThreadDemo threadDemo = new ThreadDemo();
			threadDemo.start();
			System.out.println("Main thread is running");
			for (int i = 101; i < 200; i++) {
				System.out.println("Main: " + i);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	 
	}



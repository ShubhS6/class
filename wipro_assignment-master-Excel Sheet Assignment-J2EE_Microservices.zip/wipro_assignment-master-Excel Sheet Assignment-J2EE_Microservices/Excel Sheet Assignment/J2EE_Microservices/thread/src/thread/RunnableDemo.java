package thread;


	public class RunnableDemo {
		 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			MyDemo1 myDemo1 = new MyDemo1();
			Thread t1 = new Thread(myDemo1);
			t1.start();
		}
	 
	}





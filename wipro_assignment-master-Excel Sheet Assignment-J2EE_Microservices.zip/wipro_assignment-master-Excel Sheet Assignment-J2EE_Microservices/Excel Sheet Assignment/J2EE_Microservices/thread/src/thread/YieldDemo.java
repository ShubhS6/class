package thread;


	public class YieldDemo {
		 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			MyDemo t1 = new MyDemo();
			t1.setName("Thread-1");
			MyDemo t2 = new MyDemo();
			t2.setName("Thread-2");
			MyDemo t3 = new MyDemo();
			t3.setName("Thread-3");
			
			t1.start();
			t1.yield();
			/*
			try {
				//t1.join();
				t1.yield();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			t2.start();
			t3.start();
	 
		}
	 
	}




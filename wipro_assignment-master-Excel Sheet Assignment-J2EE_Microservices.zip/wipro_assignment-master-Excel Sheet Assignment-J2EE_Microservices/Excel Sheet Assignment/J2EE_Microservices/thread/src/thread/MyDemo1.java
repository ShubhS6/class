package thread;

	class MyDemo1 implements Runnable {
		public void run() {
			System.out.println("ThreadDemo is running");
			for (int i = 0; i < 10; i++) {
				System.out.println(Thread.currentThread().getName() + " - " + i);
			}
		}
	}
	 
	
package p1;

public class BuilderDesignDemo {
	// Main class for Builder Design Pattern
	public class BuilderDesingDemo {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Person person1 = new Person.PersonBuilder()
								.setFirstName("John")
								.setLastName("Doe")
								.setAge(25)
								.build();
			
			
			Person person2 = new Person.PersonBuilder()
					.setFirstName("Alan")
					.setLastName("Jack")
					.setAge(35)
					.build();
			
		}
	 
	}
	 
}

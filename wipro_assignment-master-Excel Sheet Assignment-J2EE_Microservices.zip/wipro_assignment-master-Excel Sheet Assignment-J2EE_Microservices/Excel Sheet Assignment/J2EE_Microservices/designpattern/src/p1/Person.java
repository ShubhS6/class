package p1;
//part of Builder Design Pattern
public class Person {
	
		
		private String firstName;
		private String lastName;
		private int age;
		
		public Person(String firstName, String lastName, int age) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
		}
		
		public static class PersonBuilder{
			private String firstName;
	        private String lastName;
	        private int age;
	        
	        public PersonBuilder setFirstName(String firstName) {
	            this.firstName = firstName;
	            return this;
	        }
	        
	        public PersonBuilder setLastName(String lastName) {
	            this.lastName = lastName;
	            return this;
	        }
	        
	        public PersonBuilder setAge(int age) {
	            this.age = age;
	            return this;
	        }
	        
	        public Person build() {
	            return new Person(firstName, lastName, age);
	        }
	    }
	}
	 


package p1;

public class Singleton {

		 
		private static Singleton singleton;
	 
		private Singleton() {
			System.out.println("Singleton Object Created...");
		}
	 
		public static Singleton getInstance() {
			if (singleton == null) {
				singleton = new Singleton();
			}
			
			return singleton;
		}
	}
	 
 class SingletonDesignDemo {
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			Singleton singleton1 = Singleton.getInstance();
			Singleton singleton2 = Singleton.getInstance();
			Singleton singleton3 = Singleton.getInstance();
			System.out.println(singleton1 == singleton2);
			System.out.println(singleton1.hashCode());
			System.out.println(singleton2.hashCode());
			System.out.println(singleton3.hashCode());
			System.out.println(singleton1 == singleton3);
			
		}
	 
	}


package p1;


	public interface Shape {
		 
		void draw();
	 
	}
	 


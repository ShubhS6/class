package p1;


	public class ShapeFactory {
		
		
		public Shape getShape(String shapeType) {
	 
			if (shapeType == null) {
				return null;
			}
	 
			if (shapeType.equalsIgnoreCase("circle")) {
				return new circle();
			} else if (shapeType.equalsIgnoreCase("square")) {
				return new Square();
			}
	 
			return null;
		}
	 
	}


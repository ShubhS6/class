package com.look.jdbc;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	 
	public class CreateTable {
	 
		public static void main(String[] args) throws SQLException, ClassNotFoundException {
			// TODO Auto-generated method stub
	 
			Connection con = null;
			Statement st = null;
	 
			// 1. Loading the Driver
	 
			Class.forName("com.mysql.cj.jdbc.Driver");
	 
			// 2. Establishing the Connection
	 
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/trainerdb", "root", "Welcome@12345");
	 
			// 3. Create the Statement Object
			st = con.createStatement();
	 
			// 4. write the query to create a table
			String query = "create table students(id int, title varchar(20), description varchar(50))";
	 
			// 5. execute the query
			st.execute(query);
			System.out.println("Table Created Successfully");
	 
			
			// 7. Close the objects
			
			st.close();
			con.close();
	 
		}
	 
	}
	 



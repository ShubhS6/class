package pallinpredicate;


import java.util.function.Predicate; 

	public class t3 implements Predicate<Integer> {

	    @Override
	    public boolean test(Integer number) {
	        if (number == null || number <= 1) {
	            return false;
	        }
	        for (int i = 2; i <= Math.sqrt(number); i++) {
	            if (number % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }

	    public static void main(String[] args) {
	       
	       t3 primeCheck = new t3();

	        // Test cases
	        Integer[] testNumbers = { 2, 3, 4, 5, 10, 13, 17, 19, 20, 23, 24, 29, 31 };

	        for (Integer number : testNumbers) {
	            System.out.println(number + " is a prime number: " + primeCheck.test(number));
	        }
	    }
	}




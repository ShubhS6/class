package pallinpredicate;

	import java.util.function.Predicate;

	public class PallindromePredicate implements Predicate<String> {

	    @Override
	    public boolean test(String str) {
	        if (str == null) {
	            return false;
	        }
	        // Clean the string by removing non-alphanumeric characters and converting to lowercase
	        String cleanedStr = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
	      
	        int len = cleanedStr.length();
	        for (int i = 0; i < len / 2; i++) {
	            if (cleanedStr.charAt(i) != cleanedStr.charAt(len - 1 - i)) {
	                return false;
	            }
	        }
	        return true;
	    }

	    public static void main(String[] args) {
	    	PallindromePredicate palindromeCheck = new PallindromePredicate();
	        
	        // Test cases
	        String[] testStrings = {
	            "A man, a plan, a canal, Panama",
	            "racecar",
	            "hello",
	            "Was it a car or a cat I saw?",
	            "No lemon, no melon"
	        };

	        for (String testString : testStrings) {
	            System.out.println("\"" + testString + "\" is a palindrome: " + palindromeCheck.test(testString));
	        }
	    }
	}




package pallinpredicate;

import java.util.function.Predicate;

	

	public class c1 implements Predicate<String> {
	    private final String substring;

	    public c1(String substring) {
	        this.substring = substring;
	    }

	    @Override
	    public boolean test(String str) {
	        if (str == null || substring == null) {
	            return false;
	        }
	        return str.contains(substring);
	    }

	    public static void main(String[] args) {
	       
	        String substring = "test";

	      
	        c1 c1 = new c1(substring);//instance predcate create

	      
	        String[] testStrings = {
	            "This is a test string.",
	            "Another string without the keyword.",
	            "Test the function with multiple test cases.",
	            "No mention of the word here.",
	            "The quick brown"};


	        for (String testString : testStrings) {
	            System.out.println("\"" + testString + "\" contains \"" + substring + "\": " + c1.test(testString));
	        }
	    }
	}
	    

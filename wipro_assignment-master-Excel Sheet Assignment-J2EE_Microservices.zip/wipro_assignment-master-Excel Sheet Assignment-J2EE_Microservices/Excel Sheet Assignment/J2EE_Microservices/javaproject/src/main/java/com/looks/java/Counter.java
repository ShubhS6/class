package com.looks.java;

public class Counter {
	
	private static int count = 0;
	
	private int instanceCount = 0;
	
	public void increment() {
		count++;
		instanceCount++;
		
	}
	
	public static int getTotalCount() {
		return count;
	}
	public int getInstanceCount() {
		return instanceCount;
	}
	
	public static void main(String[] args) {
		Counter counter1= new Counter();
		
		Counter counter2= new Counter();
		
		Counter counter3= new Counter();
		
		
		counter1.increment();

		counter1.increment();

		counter2.increment();

		counter3.increment();

		counter3.increment();

		counter3.increment();
		
		System.out.println(" counter1 " +  getTotalCount() + " " + 	counter1. getInstanceCount());
		System.out.println(" counter2 " +  getTotalCount() + " " + 	counter1. getInstanceCount());
		System.out.println(" counter3" +  getTotalCount() + " " + 	counter1. getInstanceCount());
		
		
		
	}

}

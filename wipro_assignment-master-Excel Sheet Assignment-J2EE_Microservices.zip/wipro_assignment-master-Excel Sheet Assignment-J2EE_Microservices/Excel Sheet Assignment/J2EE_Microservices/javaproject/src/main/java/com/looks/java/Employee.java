package com.looks.java;

public class Employee {
	
	
	    private String name;
	    private double salary;

	    public Employee(String name, double salary) {
	        this.name = name;
	        this.salary = salary;
	    }

	
	    public void giveRaise(double amount) {
	        this.salary += amount;
	    }

	   
	    public void displayEmployeeDetails() {
	        System.out.println("Employee Name: " + this.name + ", Salary: " + this.salary);
	    }

	    public static void main(String[] args) {
	      
	        Employee emp1 = new Employee("shubham", 50000);
	        Employee emp2 = new Employee("saurav", 60000);
	        Employee emp3 = new Employee("shubham2", 70000);
	 
	        emp1.displayEmployeeDetails(); 
	        emp2.displayEmployeeDetails(); 
	        emp3.displayEmployeeDetails(); 

	     
	        emp1.giveRaise(5000);
	        emp2.giveRaise(4000);
	        emp3.giveRaise(3000);

	     
	        emp1.displayEmployeeDetails(); 
	        emp2.displayEmployeeDetails();
	        emp3.displayEmployeeDetails(); 
	    }


}

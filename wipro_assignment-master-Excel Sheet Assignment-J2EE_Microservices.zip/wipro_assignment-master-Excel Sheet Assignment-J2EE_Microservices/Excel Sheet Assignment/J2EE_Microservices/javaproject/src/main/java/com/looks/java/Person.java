package com.looks.java;

public class Person {
	
	private static int population = 0;
	
	private String name;
	
	public Person(String name) {
		this.name = name;
		population++;
	}
	
	public void display() {
		System.out.println("Name" + this.name + "current" + Person.population);
		
	}
	
	public static void main(String[] args) {
		Person person1 = new Person("sh");
		Person person2 = new Person("shu");
		Person person3 = new Person("shubo");
		
		person1.display();
		person2.display();
		person3.display();
		
		
	}
	

}

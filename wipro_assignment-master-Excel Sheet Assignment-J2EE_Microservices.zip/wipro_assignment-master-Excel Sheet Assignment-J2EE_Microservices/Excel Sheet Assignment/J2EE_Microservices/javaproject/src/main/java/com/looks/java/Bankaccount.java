package com.looks.java;

public class Bankaccount {
	private double balance;
	private static String bankName;
	
	public Bankaccount(double initialbalance) {
		this.balance = initialbalance;
		
	}
	public static void setBankname(String name) {
		bankName = name ;
	}
	
	public void deposit(double amount) {
		if (amount> 0) {
			balance += amount;
		}
	}
	public void displayAccountDetails() {
		System.out.println("" + bankName + "" + balance);
	}
	public static void main(String[] args) {
		Bankaccount.setBankname(" bank of india");
		Bankaccount account1 = new Bankaccount(100);
		Bankaccount account2 = new Bankaccount(100);
		Bankaccount account3 = new Bankaccount(100);
		
		account1.deposit(200);

		account2.deposit(200);

		account3.deposit(200);
		
		account1.displayAccountDetails();
		account2.displayAccountDetails();
		account3.displayAccountDetails();
		
	}
	
	

}

package com.looks.java;

public class configuration {
	
	
	    private static String config;

	    static {
	        config = "Default Configuration";
	        System.out.println("Static block executed. Configuration initialized to: " + config);
	    }

	 
	    public static String getConfig() {
	        return config;
	    }

	    public static void main(String[] args) {
	      
	        System.out.println("configuration Value: " + configuration.getConfig());

	        configuration config1 = new configuration();
	        configuration config2 = new configuration();

	        System.out.println("Configuration Value from config1: " + config1.getConfig());



	        System.out.println("Configuration Value from config2: " + config2.getConfig());
	    }

}

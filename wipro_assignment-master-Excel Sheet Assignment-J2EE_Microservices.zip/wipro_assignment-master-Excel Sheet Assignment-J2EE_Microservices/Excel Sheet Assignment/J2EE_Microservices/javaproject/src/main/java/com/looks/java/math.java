package com.looks.java;

public class math {
private static final double pi = 3.14;

public static double calculateCircleArea(double radius)
{
	return pi * radius * radius;
	
}

public static void main(String[] args) {
	double radius =5.0;
	double area = math.calculateCircleArea(radius);
	System.out.println("" + radius + "" + area );
}
}

package com.springjdbc.model;

import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class CommentsController {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(SpringJdbcConfigs.class);
		CommentsService service = context.getBean(CommentsService.class);
	
		service.searchComment(9001).forEach(System.out::println);
	
		
		
	}
}

package p2;

public class Ebook extends Book {
	double filesize;
	String format;
	
	public Ebook(String title, String author, String isbn, double price, double filesize, String format) {
		super(title, author, isbn, price); 
		this.filesize= filesize;
		this.format=format;
		
	}
	
	@Override
	public void displayInfo(){
		super.displayInfo();
		System.out.println(" "+ filesize);
		System.out.println("" + format);
	}

}


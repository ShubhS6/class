package p2;

public class printedBook extends Book{
	double weight;
	int shippingDays;
	

	public printedBook(String title, String author, String isbn, double price,double weight, int shippingDays) {
		super(title, author, isbn, price); 
		this.weight = weight;
		this.shippingDays= shippingDays;
		
	}
	@Override
	public void displayInfo() {
		super.displayInfo();
		System.out.println(" "+ weight);
		System.out.println("" + shippingDays);
	}

}

package p2;

public class audioBook extends Book{
	double duration;
	String narrator;


	public audioBook (String title, String author, String isbn, double price,double duration, String narrator) {
		super(title, author, isbn, price); 
		this.duration = duration;
		this.narrator= narrator;
		
	}
	
	@Override
	public void displayInfo() {
		super.displayInfo();
		System.out.println(" "+ duration);
		System.out.println("" + narrator);
	}
}

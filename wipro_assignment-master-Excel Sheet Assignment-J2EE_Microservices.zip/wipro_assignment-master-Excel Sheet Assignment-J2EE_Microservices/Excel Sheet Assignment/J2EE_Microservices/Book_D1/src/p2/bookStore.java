package p2;

import java.util.ArrayList;
import java.util.List;

public class bookStore {
 private List<Book>books;
 public bookStore() {
	 books = new ArrayList<>();
 }
 
 public void addBook(Book book) {
	 books.add(book);
	 
 }
 
 public void displayAllBooks() {
	 for(Book book : books) {
		 book.displayInfo();
		 System.out.println();
	 }
 }
 
 public static void main(String[] args) {
	 bookStore store = new bookStore();
	 
	 
	 Ebook ebook = new Ebook("champak","shubh","1234567890",80,2.5,"pdf" );
	 printedBook printedBook = new printedBook("oxygen","shubham","1234567890",20,5,7 );
	 audioBook audioBook = new audioBook("dhyan","saurav","1234567890",10,50,"patekar");
	 
	 
	 store.addBook(ebook);
	 
	 store.addBook(printedBook);
	 store.addBook(audioBook);
	 
	 store.displayAllBooks();
	 		
 }
}

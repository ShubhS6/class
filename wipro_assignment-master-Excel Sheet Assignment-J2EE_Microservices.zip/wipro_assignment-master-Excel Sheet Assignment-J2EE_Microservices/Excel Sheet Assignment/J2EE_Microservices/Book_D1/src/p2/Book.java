package p2;

public class Book {
	String title;
	String author;
	String isbn;
	double price;
	
	public Book(String title,String author,String isbn,double price) {
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.price= price;}
	
	public void displayInfo() {
		System.out.println(" " + title);
		System.out.println(" " + author);
		System.out.println(" " + isbn);
		System.out.println(" " + price);
	}
	
	

}

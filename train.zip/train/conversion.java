package javaClass;

import java.util.Scanner;

public class conversion {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter length in centimeter: ");
        double c = sc.nextDouble();
        
        double m = convertCentimetersToMeters(c);
        double km = convertCentimetersToKilometers(m);
        
        System.out.printf("Length in meter = %.2f m\n", m);
        System.out.printf("Length in kilometer = %.5f km\n", km);
    }
    
    public static double convertCentimetersToMeters(double c) {
        return c / 100;
    }
    
    public static double convertCentimetersToKilometers(double c) {
        return c / 100000;
    }
}

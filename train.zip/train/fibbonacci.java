package javaClass;


import java.util.Scanner;
class fib{
	private int s;
	
	public fib(int s) {
		this.s=s;
	}
	public void ps() {
		int a=0,b=1;
		for(int i=0;i<=s;i++)
		{
			System.out.println(a);
			int temp=a+b;
			a=b;
			b=temp;
		}
	}
}
public class fibbonacci {
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		fib fs=new fib(n);
		fs.ps();
	}
}

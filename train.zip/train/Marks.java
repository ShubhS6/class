package javaClass;
import java.util.*;

public class Marks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Enter marks for 5 subjects:");

        System.out.print("Subject 1: ");
        int subject1 = scanner.nextInt();

        System.out.print("Subject 2: ");
        int subject2 = scanner.nextInt();

        System.out.print("Subject 3: ");
        int subject3 = scanner.nextInt();

        System.out.print("Subject 4: ");
        int subject4 = scanner.nextInt();

        System.out.print("Subject 5: ");
        int subject5 = scanner.nextInt();

   
        int totalMarks = subject1 + subject2 + subject3 + subject4 + subject5;
        double percentage = (totalMarks / 500.0) * 100;

       
        int division;
        if (percentage >= 75) {
            division = 1; 
        } else if (percentage >= 60) {
            division = 2;
        } else if (percentage >= 50) {
            division = 3; 
        } else if (percentage >= 40) {
            division = 4; 
        } else {
            division = 5; 
        }

        
        switch (division) {
            case 1:
                System.out.println("Honors above 75%");
                break;
            case 2:
                System.out.println("First Division above 60%");
                break;
            case 3:
                System.out.println("Second Division above 50%");
                break;
            case 4:
                System.out.println("Third Division above 40%");
                break;
            case 5:
                System.out.println("Failed below 40%");
                break;
            default:
                System.out.println("Invalid percentage");
                break;
        }

        scanner.close();
    }
}


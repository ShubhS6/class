package javaClass;

import java.util.Scanner;

public class SwappingNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Input first number: ");
        int fN = sc.nextInt();
        
        System.out.print("Input second number: ");
        int sN = sc.nextInt();
        
        System.out.println("First number before swapping: " + fN);
        System.out.println("Second number before swapping: " + sN);
        
        int temp = fN;
        fN = sN;
        sN = temp;
        
        System.out.println("First number after swapping: " + fN);
        System.out.println("Second number after swapping: " + sN);
    }
}

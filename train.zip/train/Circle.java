package javaClass;
import java.util.Scanner;
	
public class Circle {
	  public static void main(String[] args) {
	      Scanner sc = new Scanner(System.in);
	        
	      System.out.print("Enter radius: ");
	      double r = sc.nextDouble();
	        
	      double d = 2 * r;
	      double c = 2 * Math.PI * r;
	      double a = Math.PI * r * r;
	        
	      System.out.printf("Diameter = %.2f ", d);
	      System.out.printf("Circumference = %.2f ", c);
	      System.out.printf("Area = %.2f ", a);
	   }
}

